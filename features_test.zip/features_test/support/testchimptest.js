module.exports = function() {

  this.Given(/^Open "([^"]*)"$/, function (fileurl) {
     browser.url(fileurl);
  });

  this.When(/^Input "([^"]*)";"([^"]*)";"([^"]*)"$/, function (fname,lname,phone) {
    browser.setValue('input[id="fname"]', fname);
    browser.setValue('input[id="lname"]', lname);
    browser.setValue('input[id="phone"]', phone);
    browser.click('button[id="submit"]');

    
  });

  this.Then(/^I should get response "([^"]*)";"([^"]*)";"([^"]*)"$/, function (fname,lname,phone) {

    var text = browser.getText('#fname-submit');
	expect(text == fname).toBe(true);
    var text = browser.getText('#lname-submit');
        expect(text == lname).toBe(true);
    var text = browser.getText('#phone-submit');
        expect(text == phone).toBe(true);
  });

 this.Then(/^I should get error code "([^"]*)";"([^"]*)";"([^"]*)"$/, function (fname,lname,phone) {

    var text = browser.getText('#fname-error');
	expect(text == fname).toBe(true);
    var text = browser.getText('#lname-error');
        expect(text == lname).toBe(true);
    var text = browser.getText('#phone-error');
        expect(text == phone).toBe(true);
  });
  
}